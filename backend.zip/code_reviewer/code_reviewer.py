import reflex as rx

from .components.navbar import navbar
from .state import CodeState


UPLOAD_ID = "python_code_upload"


def stat_card(label: str, value, accent: str) -> rx.Component:
    return rx.box(
        rx.text(
            label,
            font_size="0.82rem",
            text_transform="uppercase",
            letter_spacing="0.08em",
            color="#64748b",
        ),
        rx.heading(value, size="7", color="#0f172a"),
        padding="1rem 1.1rem",
        border_radius="18px",
        background="rgba(255, 255, 255, 0.82)",
        border=f"1px solid {accent}",
        box_shadow="0 16px 38px rgba(15, 23, 42, 0.08)",
        width="100%",
    )


def section_panel(title: str, subtitle: str, *children) -> rx.Component:
    return rx.box(
        rx.vstack(
            rx.box(
                rx.heading(
                    title,
                    size="6",
                    color="#0f172a",
                    font_family="'Space Grotesk', 'Trebuchet MS', sans-serif",
                ),
                rx.text(subtitle, color="#475569", font_size="0.95rem"),
                spacing="1",
                width="100%",
            ),
            *children,
            spacing="4",
            width="100%",
            align="stretch",
        ),
        padding="1.35rem",
        border_radius="24px",
        background="rgba(255, 255, 255, 0.9)",
        border="1px solid rgba(148, 163, 184, 0.22)",
        box_shadow="0 18px 48px rgba(15, 23, 42, 0.08)",
        width="100%",
    )


def finding_row(finding: str) -> rx.Component:
    return rx.box(
        rx.text(
            finding,
            color="#0f172a",
            white_space="pre-wrap",
            line_height="1.55",
        ),
        padding="0.9rem 1rem",
        border_radius="16px",
        background="#f8fafc",
        border="1px solid #e2e8f0",
        width="100%",
    )


def code_panel(title: str, value, accent: str) -> rx.Component:
    return rx.vstack(
        rx.text(
            title,
            color="#334155",
            font_weight="600",
            font_size="0.95rem",
        ),
        rx.text_area(
            value=value,
            read_only=True,
            width="100%",
            min_height="420px",
            resize="vertical",
            background="#020617",
            color="#e2e8f0",
            border=f"1px solid {accent}",
            border_radius="18px",
            font_family="'IBM Plex Mono', 'Consolas', monospace",
            padding="1rem",
        ),
        spacing="3",
        width="100%",
        align="stretch",
    )


def index():
    return rx.box(
        navbar(),
        rx.box(
            rx.vstack(
                rx.box(
                    rx.vstack(
                        rx.badge(
                            "Static review + model review",
                            radius="full",
                            variant="soft",
                            color_scheme="orange",
                            size="3",
                        ),
                        rx.heading(
                            "Upload Python code, catch structural issues, then send the clean context to an LLM.",
                            size="8",
                            color="#fff7ed",
                            font_family="'Space Grotesk', 'Trebuchet MS', sans-serif",
                            line_height="1.1",
                        ),
                        rx.text(
                            "This reviewer parses code with Python AST, flags syntax and probable logic problems, checks a few PEP-style rules, and then asks a language model for higher-level analysis.",
                            color="#ffedd5",
                            font_size="1rem",
                            max_width="54rem",
                            line_height="1.7",
                        ),
                        spacing="3",
                        align="start",
                    ),
                    width="100%",
                    padding="1.8rem",
                    border_radius="28px",
                    background="linear-gradient(135deg, rgba(180, 83, 9, 0.92) 0%, rgba(194, 65, 12, 0.88) 38%, rgba(30, 64, 175, 0.88) 100%)",
                    box_shadow="0 26px 65px rgba(30, 41, 59, 0.18)",
                ),
                rx.flex(
                    stat_card("Errors", CodeState.error_count, "#fecaca"),
                    stat_card("Warnings", CodeState.warning_count, "#fed7aa"),
                    stat_card("Notes", CodeState.info_count, "#bfdbfe"),
                    stat_card("Lines", CodeState.line_count, "#cbd5e1"),
                    wrap="wrap",
                    spacing="4",
                    width="100%",
                ),
                section_panel(
                    "Input",
                    "Choose a Python file or paste source directly into the editor.",
                    rx.upload(
                        rx.vstack(
                            rx.text(
                                "Drop a .py file here",
                                font_size="1.05rem",
                                font_weight="600",
                                color="#0f172a",
                            ),
                            rx.text(
                                "or click to browse from your machine",
                                color="#64748b",
                            ),
                            spacing="2",
                            align="center",
                            width="100%",
                        ),
                        id=UPLOAD_ID,
                        accept={"text/plain": [".py", ".pyi", ".txt"]},
                        max_files=1,
                        multiple=False,
                        width="100%",
                        padding="2.2rem 1rem",
                        border="1.5px dashed #94a3b8",
                        border_radius="20px",
                        background="linear-gradient(180deg, rgba(255,255,255,0.82) 0%, rgba(241,245,249,0.98) 100%)",
                    ),
                    rx.flex(
                        rx.foreach(
                            rx.selected_files(UPLOAD_ID),
                            lambda name: rx.badge(
                                name,
                                radius="full",
                                color_scheme="blue",
                                variant="soft",
                                size="3",
                            ),
                        ),
                        rx.spacer(),
                        rx.button(
                            "Load file",
                            on_click=CodeState.handle_upload(
                                rx.upload_files(upload_id=UPLOAD_ID)
                            ),
                            background="#1d4ed8",
                            color="white",
                            border_radius="999px",
                        ),
                        width="100%",
                        align="center",
                        gap="0.75rem",
                        wrap="wrap",
                    ),
                    rx.text(
                        CodeState.syntax_message,
                        color="#334155",
                        font_size="0.95rem",
                    ),
                    rx.text_area(
                        value=CodeState.code_input,
                        on_change=CodeState.update_code_input,
                        placeholder="Paste Python code here if you do not want to upload a file.",
                        width="100%",
                        min_height="360px",
                        resize="vertical",
                        background="#0f172a",
                        color="#e2e8f0",
                        border_radius="20px",
                        font_family="'IBM Plex Mono', 'Consolas', monospace",
                        padding="1rem",
                    ),
                    rx.flex(
                        rx.button(
                            "Analyze code",
                            on_click=CodeState.analyze,
                            loading=CodeState.is_loading,
                            background="#c2410c",
                            color="white",
                            border_radius="999px",
                            size="3",
                        ),
                        rx.button(
                            "Load sample",
                            on_click=CodeState.load_sample,
                            variant="soft",
                            color_scheme="amber",
                            border_radius="999px",
                            size="3",
                        ),
                        rx.button(
                            "Clear",
                            on_click=CodeState.clear_workspace,
                            variant="outline",
                            color_scheme="gray",
                            border_radius="999px",
                            size="3",
                        ),
                        gap="0.75rem",
                        wrap="wrap",
                    ),
                    rx.cond(
                        CodeState.error_message != "",
                        rx.box(
                            rx.text(
                                CodeState.error_message,
                                color="#991b1b",
                                font_weight="600",
                            ),
                            padding="0.9rem 1rem",
                            border_radius="16px",
                            background="#fef2f2",
                            border="1px solid #fecaca",
                            width="100%",
                        ),
                    ),
                ),
                rx.cond(
                    CodeState.review_ready,
                    rx.vstack(
                        section_panel(
                            "Static Review",
                            "Local analysis combines AST checks, syntax parsing, and lightweight PEP-oriented rules.",
                            rx.text(
                                CodeState.review_summary,
                                color="#0f172a",
                                font_weight="500",
                            ),
                            rx.flex(
                                stat_card("Non-empty lines", CodeState.non_empty_lines, "#dbeafe"),
                                stat_card("Functions", CodeState.function_count, "#fde68a"),
                                stat_card("Classes", CodeState.class_count, "#c7d2fe"),
                                stat_card("Imports", CodeState.import_count, "#fecdd3"),
                                wrap="wrap",
                                spacing="4",
                                width="100%",
                            ),
                            rx.cond(
                                CodeState.has_findings,
                                rx.vstack(
                                    rx.foreach(CodeState.findings, finding_row),
                                    spacing="3",
                                    width="100%",
                                ),
                                rx.box(
                                    rx.text(
                                        "No static findings were reported for this file.",
                                        color="#166534",
                                        font_weight="600",
                                    ),
                                    padding="1rem",
                                    border_radius="16px",
                                    background="#ecfdf5",
                                    border="1px solid #bbf7d0",
                                ),
                            ),
                        ),
                        section_panel(
                            "LLM Review",
                            "The model now returns both analysis and a corrected version of the code.",
                            rx.flex(
                                rx.badge(
                                    CodeState.llm_status,
                                    radius="full",
                                    variant="soft",
                                    color_scheme="indigo",
                                    size="3",
                                ),
                                rx.badge(
                                    CodeState.llm_provider,
                                    radius="full",
                                    variant="soft",
                                    color_scheme="cyan",
                                    size="3",
                                ),
                                gap="0.75rem",
                                wrap="wrap",
                            ),
                            rx.box(
                                rx.markdown(CodeState.llm_review),
                                padding="1rem",
                                border_radius="18px",
                                background="#f8fafc",
                                border="1px solid #e2e8f0",
                                width="100%",
                            ),
                            rx.flex(
                                code_panel("Input code", CodeState.code_input, "#1d4ed8"),
                                code_panel(
                                    "LLM corrected code",
                                    CodeState.corrected_code,
                                    "#c2410c",
                                ),
                                direction="row",
                                wrap="wrap",
                                gap="1rem",
                                width="100%",
                                align="stretch",
                            ),
                        ),
                        spacing="5",
                        width="100%",
                    ),
                ),
                spacing="5",
                width="100%",
                max_width="1120px",
                align="stretch",
            ),
            width="100%",
            min_height="100vh",
            padding="1.5rem",
            background=(
                "radial-gradient(circle at top left, rgba(251, 191, 36, 0.18), transparent 32%), "
                "radial-gradient(circle at top right, rgba(59, 130, 246, 0.16), transparent 28%), "
                "linear-gradient(180deg, #fff8ef 0%, #f8fafc 46%, #eef2ff 100%)"
            ),
        ),
    )


app = rx.App()
app.add_page(index, title="AI Code Reviewer")
