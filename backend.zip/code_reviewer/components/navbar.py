import reflex as rx


def navbar():
    return rx.box(
        rx.flex(
            rx.vstack(
                rx.heading(
                    "AI Code Reviewer",
                    size="7",
                    color="#f8fafc",
                    font_family="'Space Grotesk', 'Trebuchet MS', sans-serif",
                ),
                rx.text(
                    "AST checks first, LLM reasoning second.",
                    color="#cbd5e1",
                    font_size="0.95rem",
                ),
                spacing="1",
                align="start",
            ),
            rx.badge(
                "Reflex + Python",
                color_scheme="gray",
                radius="full",
                variant="soft",
                size="3",
            ),
            justify="between",
            align="center",
            width="100%",
        ),
        width="100%",
        padding="1.2rem 1.5rem",
        background="linear-gradient(135deg, #102542 0%, #1f3b73 52%, #b85c38 100%)",
        border_bottom="1px solid rgba(255, 255, 255, 0.12)",
        box_shadow="0 18px 50px rgba(16, 37, 66, 0.28)",
    )
